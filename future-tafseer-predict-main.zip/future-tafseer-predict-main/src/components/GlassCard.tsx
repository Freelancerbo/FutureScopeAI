import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export default function GlassCard({ children, className, hover = true }: GlassCardProps) {
  return (
    <div
      className={cn(
        "glass rounded-xl p-6",
        hover && "transition-all duration-300 hover:bg-card/80 hover:border-primary/20 hover:shadow-[0_0_30px_hsl(var(--glow-primary))]",
        className
      )}
    >
      {children}
    </div>
  );
}
