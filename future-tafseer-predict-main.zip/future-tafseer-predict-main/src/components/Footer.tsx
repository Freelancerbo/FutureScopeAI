import { Link } from "react-router-dom";
import { Brain, Sparkles } from "lucide-react";

const footerLinks = [
  {
    title: "Platform",
    links: [
      { label: "Dashboard", to: "/dashboard" },
      { label: "Predict Future", to: "/predict" },
      { label: "Investments", to: "/investments" },
      { label: "AI Assistant", to: "/ai-assistant" },
    ],
  },
  {
    title: "Community",
    links: [
      { label: "Professionals", to: "/professionals" },
      { label: "Saved Items", to: "/saved" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", to: "/about" },
      { label: "Contact Us", to: "/contact" },
      { label: "FAQ", to: "/faq" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", to: "/privacy" },
      { label: "Terms & Conditions", to: "/terms" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="border-t border-border bg-card/40">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Brain className="w-6 h-6 text-primary" />
              <span className="font-display font-bold gradient-text">FutureScope AI</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              AI-powered predictions, investments & professional insights for the future.
            </p>
          </div>
          {footerLinks.map((section) => (
            <div key={section.title}>
              <h4 className="font-display font-semibold text-sm mb-3">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.to}>
                    <Link to={link.to} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-border mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            Built by Tafseer <Sparkles className="w-3 h-3 text-primary" />
          </p>
          <p className="text-xs text-muted-foreground">
            ⚠️ AI-generated predictions are for informational purposes only.
          </p>
        </div>
      </div>
    </footer>
  );
}
