import PageWrapper from "@/components/PageWrapper";

export default function Privacy() {
  return (
    <PageWrapper className="container mx-auto px-4 py-8 max-w-3xl">
      <h1 className="font-display text-3xl font-bold mb-6">Privacy Policy</h1>
      <div className="prose prose-invert prose-sm max-w-none space-y-6 text-muted-foreground">
        <p>Last updated: February 2026</p>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">1. Information We Collect</h2>
          <p>We collect information you provide directly to us, such as when you create an account, make predictions, save investment ideas, or contact us. This may include your name, email address, and usage data.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">2. How We Use Information</h2>
          <p>We use the information to provide, maintain, and improve our services, personalize your experience, and develop new features. Your prediction data helps improve our AI models.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">3. Data Security</h2>
          <p>We implement industry-standard security measures to protect your personal information. All data is encrypted in transit and at rest.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">4. Data Sharing</h2>
          <p>We do not sell your personal data. We may share anonymized, aggregated data for research purposes. Professional profiles and public posts are visible to other users.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">5. Your Rights</h2>
          <p>You can access, update, or delete your personal information at any time through your account settings. Contact us at support@futurescope.ai for assistance.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">6. Contact</h2>
          <p>For privacy-related inquiries, contact us at support@futurescope.ai or call +92 325 7558149.</p>
        </section>
      </div>
    </PageWrapper>
  );
}
