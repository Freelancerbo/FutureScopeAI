import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, MessageCircle, Share2, UserPlus, Search, Briefcase } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

const professionals = [
  { name: "Dr. Sarah Khan", role: "AI Researcher", specialty: "Machine Learning", followers: 2340, posts: 45, avatar: "SK" },
  { name: "Ali Hassan", role: "Blockchain Developer", specialty: "Smart Contracts", followers: 1890, posts: 32, avatar: "AH" },
  { name: "Fatima Zahra", role: "Climate Scientist", specialty: "Climate Tech", followers: 3100, posts: 67, avatar: "FZ" },
  { name: "Ahmed Raza", role: "Financial Analyst", specialty: "Investment Strategy", followers: 1560, posts: 28, avatar: "AR" },
  { name: "Maria Gonzalez", role: "EdTech Expert", specialty: "Online Learning", followers: 980, posts: 19, avatar: "MG" },
  { name: "James Chen", role: "Startup Advisor", specialty: "SaaS & Growth", followers: 4200, posts: 89, avatar: "JC" },
];

const posts = [
  { author: "Dr. Sarah Khan", role: "AI Researcher", content: "The next wave of AI won't replace developers — it will create a new tier of 'AI architects' who orchestrate multiple AI systems. Start learning prompt orchestration now.", likes: 234, comments: 45, avatar: "SK", time: "2h ago" },
  { author: "Ali Hassan", role: "Blockchain Developer", content: "Just published my analysis on how ZK-rollups will reduce Ethereum gas fees by 90% by 2027. The implications for DeFi accessibility are massive.", likes: 189, comments: 32, avatar: "AH", time: "5h ago" },
  { author: "Ahmed Raza", role: "Financial Analyst", content: "Pakistan's tech exports grew 30% last quarter. The freelance ecosystem is maturing into full agencies. This is the decade for South Asian tech.", likes: 312, comments: 67, avatar: "AR", time: "1d ago" },
];

export default function Professionals() {
  const [following, setFollowing] = useState<Set<number>>(new Set());
  const [search, setSearch] = useState("");

  const toggleFollow = (i: number) => {
    setFollowing((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  const filteredProfessionals = professionals.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.role.toLowerCase().includes(search.toLowerCase()) ||
      p.specialty.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <PageWrapper className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold mb-1">
          <span className="gradient-text">Professionals</span> Platform
        </h1>
        <p className="text-muted-foreground">Expert insights, predictions & ideas from industry leaders</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Professionals List */}
        <div>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search professionals..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-secondary border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
          <div className="space-y-3">
            {filteredProfessionals.map((pro, i) => (
              <GlassCard key={pro.name} className="py-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-sm font-bold text-primary-foreground">
                    {pro.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{pro.name}</div>
                    <div className="text-xs text-muted-foreground">{pro.role}</div>
                  </div>
                  <button
                    onClick={() => toggleFollow(i)}
                    className={`p-2 rounded-lg transition-colors ${
                      following.has(i)
                        ? "bg-primary/20 text-primary"
                        : "bg-secondary text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <UserPlus className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                  <span>{pro.followers.toLocaleString()} followers</span>
                  <span>{pro.posts} posts</span>
                  <span className="text-primary">{pro.specialty}</span>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>

        {/* Feed */}
        <div className="lg:col-span-2">
          <h2 className="font-display text-xl font-semibold mb-4 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-primary" /> Latest Insights
          </h2>
          <div className="space-y-4">
            {posts.map((post, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xs font-bold text-primary-foreground">
                      {post.avatar}
                    </div>
                    <div>
                      <div className="font-medium text-sm">{post.author}</div>
                      <div className="text-xs text-muted-foreground">{post.role} · {post.time}</div>
                    </div>
                  </div>
                  <p className="text-sm text-foreground/90 leading-relaxed mb-4">{post.content}</p>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <button className="flex items-center gap-1 hover:text-destructive transition-colors">
                      <Heart className="w-4 h-4" /> {post.likes}
                    </button>
                    <button className="flex items-center gap-1 hover:text-primary transition-colors">
                      <MessageCircle className="w-4 h-4" /> {post.comments}
                    </button>
                    <button className="flex items-center gap-1 hover:text-foreground transition-colors">
                      <Share2 className="w-4 h-4" /> Share
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </PageWrapper>
  );
}
