import { Bookmark, Trash2 } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

const savedItems = [
  { type: "Prediction", title: "AI in Healthcare 2026", date: "2 days ago" },
  { type: "Investment", title: "Solar Energy Farms", date: "3 days ago" },
  { type: "Post", title: "The Future of Remote Work", date: "1 week ago" },
];

export default function Saved() {
  return (
    <PageWrapper className="container mx-auto px-4 py-8">
      <h1 className="font-display text-3xl font-bold mb-2">
        <span className="gradient-text">Saved</span> Items
      </h1>
      <p className="text-muted-foreground mb-8">Your bookmarked predictions, ideas & posts</p>

      {savedItems.length === 0 ? (
        <GlassCard className="text-center py-16">
          <Bookmark className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No saved items yet. Start exploring!</p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {savedItems.map((item, i) => (
            <GlassCard key={i} className="flex items-center justify-between py-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Bookmark className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="font-medium text-sm">{item.title}</div>
                  <div className="text-xs text-muted-foreground">{item.type} · {item.date}</div>
                </div>
              </div>
              <button className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            </GlassCard>
          ))}
        </div>
      )}
    </PageWrapper>
  );
}
