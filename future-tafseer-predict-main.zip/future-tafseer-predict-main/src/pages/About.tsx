import { Brain, Target, Users, Lightbulb, Sparkles } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

export default function About() {
  return (
    <PageWrapper className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="text-center mb-12">
        <h1 className="font-display text-3xl md:text-4xl font-bold mb-3">
          About <span className="gradient-text">FutureScope AI</span>
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          We're building the world's most advanced AI-powered platform for future predictions, investment insights, and professional networking.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4 mb-12">
        {[
          { icon: Target, title: "Our Mission", desc: "Democratize access to AI-powered foresight so everyone can make smarter decisions about their future." },
          { icon: Brain, title: "AI-First", desc: "Every feature is powered by advanced AI models trained on global data, trends, and expert analysis." },
          { icon: Users, title: "Community-Driven", desc: "Thousands of professionals share insights, building a collective intelligence network." },
          { icon: Lightbulb, title: "Innovation", desc: "We continuously push the boundaries of what's possible with predictive AI and real-time analytics." },
        ].map((item) => (
          <GlassCard key={item.title}>
            <item.icon className="w-8 h-8 text-primary mb-3" />
            <h3 className="font-display font-semibold mb-2">{item.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="text-center">
        <Sparkles className="w-8 h-8 text-primary mx-auto mb-3" />
        <h2 className="font-display text-xl font-bold mb-2">Built by Tafseer</h2>
        <p className="text-sm text-muted-foreground">
          FutureScope AI is designed and developed with passion for making AI accessible to everyone around the world.
        </p>
      </GlassCard>
    </PageWrapper>
  );
}
