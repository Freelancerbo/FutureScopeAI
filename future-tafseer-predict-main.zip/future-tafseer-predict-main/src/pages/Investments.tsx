import { useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, Shield, Bookmark, Share2, Filter } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

const riskColors = { Low: "text-green-400 bg-green-500/10", Medium: "text-yellow-400 bg-yellow-500/10", High: "text-red-400 bg-red-500/10" };

const ideas = [
  { title: "AI SaaS Micro-Tools", category: "Startups", risk: "Medium" as const, description: "Build niche AI tools for specific industries. Low barrier to entry with high margins.", region: "Global", potential: "High" },
  { title: "Solar Energy Farms", category: "Real Estate", risk: "Low" as const, description: "Invest in solar farms in developing regions. Government subsidies available.", region: "Pakistan", potential: "Medium" },
  { title: "Ethereum Staking", category: "Crypto", risk: "High" as const, description: "Stake ETH for passive returns. Market volatility is a factor.", region: "Global", potential: "High" },
  { title: "EdTech Platform", category: "Online Business", risk: "Medium" as const, description: "Create localized educational content for emerging markets.", region: "South Asia", potential: "High" },
  { title: "Freelance Dev Agency", category: "Skills", risk: "Low" as const, description: "Build a team of developers offering specialized services to Western companies.", region: "Pakistan", potential: "Medium" },
  { title: "DeFi Yield Farming", category: "Crypto", risk: "High" as const, description: "Provide liquidity to DeFi protocols for yield. Advanced knowledge required.", region: "Global", potential: "High" },
];

const categoryFilters = ["All", "Startups", "Crypto", "Real Estate", "Skills", "Online Business"];

export default function Investments() {
  const [filter, setFilter] = useState("All");
  const [savedIds, setSavedIds] = useState<Set<number>>(new Set());

  const filtered = filter === "All" ? ideas : ideas.filter((i) => i.category === filter);

  const toggleSave = (i: number) => {
    setSavedIds((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  return (
    <PageWrapper className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold">
            Investment <span className="gradient-text">Ideas</span>
          </h1>
          <p className="text-muted-foreground mt-1">AI-generated investment opportunities — local & global</p>
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <div className="flex flex-wrap gap-2">
            {categoryFilters.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  filter === cat ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((idea, i) => (
          <motion.div
            key={idea.title}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <GlassCard>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary">{idea.category}</span>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${riskColors[idea.risk]}`}>
                  <Shield className="w-3 h-3 inline mr-1" />{idea.risk} Risk
                </span>
              </div>
              <h3 className="font-display font-semibold mb-2">{idea.title}</h3>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{idea.description}</p>
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                <span>🌍 {idea.region}</span>
                <span className="flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" /> {idea.potential} potential
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleSave(i)}
                  className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-colors ${
                    savedIds.has(i) ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Bookmark className="w-3 h-3" /> {savedIds.has(i) ? "Saved" : "Save"}
                </button>
                <button className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-secondary text-muted-foreground hover:text-foreground text-xs font-medium transition-colors">
                  <Share2 className="w-3 h-3" /> Share
                </button>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </PageWrapper>
  );
}
