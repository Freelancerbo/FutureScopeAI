import { useState } from "react";
import { motion } from "framer-motion";
import { Brain, Zap, Clock, TrendingUp, ChevronRight, Search } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

const categories = ["Career", "Technology", "Business", "Crypto", "Climate", "Education", "Health"];

const samplePredictions = [
  {
    topic: "AI in Software Development",
    shortTerm: "AI coding assistants will become standard in 80% of dev teams. Junior roles will shift toward AI supervision and prompt engineering.",
    longTerm: "Fully autonomous code generation for simple apps. Developers become architects and AI orchestrators. New roles emerge around AI ethics and testing.",
    confidence: 91,
    reason: "Based on current adoption rates of GitHub Copilot, cursor, and enterprise AI tools showing 300% YoY growth.",
  },
  {
    topic: "Cryptocurrency Market",
    shortTerm: "Bitcoin likely to see institutional adoption grow with new ETF products. Altcoin market consolidation expected.",
    longTerm: "Central Bank Digital Currencies (CBDCs) will coexist with decentralized crypto. DeFi matures with regulatory frameworks.",
    confidence: 74,
    reason: "Regulatory trends in US and EU, combined with BlackRock and Fidelity's crypto positions indicate institutional acceptance.",
  },
];

export default function Predict() {
  const [topic, setTopic] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showResults, setShowResults] = useState(false);

  const handlePredict = () => {
    if (topic.trim() || selectedCategory) {
      setShowResults(true);
    }
  };

  return (
    <PageWrapper className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="font-display text-3xl md:text-4xl font-bold mb-3">
            Predict the <span className="gradient-text">Future</span>
          </h1>
          <p className="text-muted-foreground">Enter any topic and let AI forecast what's coming next</p>
        </div>

        {/* Input Section */}
        <GlassCard className="mb-8">
          <div className="flex gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handlePredict()}
                placeholder="Enter a topic... (e.g., AI jobs, crypto, climate tech)"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <button
              onClick={handlePredict}
              className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-opacity flex items-center gap-2"
            >
              <Zap className="w-4 h-4" /> Predict
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => { setSelectedCategory(cat); setTopic(cat); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  selectedCategory === cat
                    ? "bg-primary/20 text-primary border border-primary/30"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </GlassCard>

        {/* Results */}
        {showResults && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {samplePredictions.map((pred, i) => (
              <GlassCard key={i}>
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-display text-xl font-bold">{pred.topic}</h3>
                  <div className="flex items-center gap-2">
                    <div className="text-sm text-muted-foreground">Confidence</div>
                    <div className="font-display font-bold text-primary">{pred.confidence}%</div>
                  </div>
                </div>

                {/* Confidence Bar */}
                <div className="w-full bg-secondary rounded-full h-2 mb-6">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pred.confidence}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                    className="h-2 rounded-full bg-gradient-to-r from-primary to-accent"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="p-4 rounded-xl bg-secondary/50 border border-border">
                    <div className="flex items-center gap-2 mb-2 text-primary">
                      <Clock className="w-4 h-4" />
                      <span className="font-display font-semibold text-sm">Short-term (1–3 years)</span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{pred.shortTerm}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-secondary/50 border border-border">
                    <div className="flex items-center gap-2 mb-2 text-accent">
                      <TrendingUp className="w-4 h-4" />
                      <span className="font-display font-semibold text-sm">Long-term (5–10 years)</span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{pred.longTerm}</p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                  <div className="flex items-center gap-2 mb-1">
                    <Brain className="w-4 h-4 text-primary" />
                    <span className="text-xs font-semibold text-primary">Why this prediction</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{pred.reason}</p>
                </div>
              </GlassCard>
            ))}
          </motion.div>
        )}
      </div>
    </PageWrapper>
  );
}
