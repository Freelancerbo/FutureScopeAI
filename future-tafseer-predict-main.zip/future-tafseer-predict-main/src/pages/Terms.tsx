import PageWrapper from "@/components/PageWrapper";

export default function Terms() {
  return (
    <PageWrapper className="container mx-auto px-4 py-8 max-w-3xl">
      <h1 className="font-display text-3xl font-bold mb-6">Terms & Conditions</h1>
      <div className="prose prose-invert prose-sm max-w-none space-y-6 text-muted-foreground">
        <p>Last updated: February 2026</p>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">1. Acceptance of Terms</h2>
          <p>By accessing or using FutureScope AI, you agree to be bound by these Terms and Conditions. If you do not agree, please do not use our services.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">2. AI Predictions Disclaimer</h2>
          <p>AI-generated predictions are for informational purposes only. They should not be considered as financial, medical, legal, or professional advice. Users are responsible for their own decisions.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">3. User Accounts</h2>
          <p>You are responsible for maintaining the confidentiality of your account credentials. You must provide accurate information when creating an account.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">4. Professional Content</h2>
          <p>Professionals are responsible for the accuracy of their posts and predictions. FutureScope AI does not verify professional credentials and is not liable for user-generated content.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">5. Premium Services</h2>
          <p>Premium features require a paid subscription. Payments are processed through JazzCash, EasyPaisa, and other supported methods. Refund policies apply as per our refund guidelines.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">6. Limitation of Liability</h2>
          <p>FutureScope AI shall not be liable for any damages arising from the use of our predictions, investment ideas, or any other content on the platform.</p>
        </section>

        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">7. Contact</h2>
          <p>For questions about these terms, contact us at support@futurescope.ai or call +92 325 7558149.</p>
        </section>
      </div>
    </PageWrapper>
  );
}
