import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, TrendingUp, Users, Globe, BarChart3, Zap, ArrowUp, ArrowDown } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

const dashboardMessages = [
  "Your AI insights are updating...",
  "Scanning global trends for you...",
  "New predictions available...",
  "Markets are shifting — stay ahead.",
];

const recentPredictions = [
  { title: "AI Job Market Growth", status: "up", change: "+15%", time: "2 hours ago" },
  { title: "Crypto Winter Ending", status: "up", change: "+8%", time: "5 hours ago" },
  { title: "Traditional Retail Decline", status: "down", change: "-12%", time: "1 day ago" },
  { title: "Green Tech Surge", status: "up", change: "+22%", time: "1 day ago" },
];

export default function Dashboard() {
  const [msgIndex, setMsgIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setMsgIndex((i) => (i + 1) % dashboardMessages.length), 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <PageWrapper className="container mx-auto px-4 py-8">
      {/* Dynamic Header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold mb-2">Dashboard</h1>
        <AnimatePresence mode="wait">
          <motion.p
            key={msgIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-muted-foreground text-sm"
          >
            {dashboardMessages[msgIndex]}
          </motion.p>
        </AnimatePresence>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { icon: Brain, label: "My Predictions", value: "24", color: "text-primary" },
          { icon: TrendingUp, label: "Saved Ideas", value: "12", color: "text-green-400" },
          { icon: Users, label: "Following", value: "38", color: "text-accent" },
          { icon: Globe, label: "Active Topics", value: "7", color: "text-yellow-400" },
        ].map((stat) => (
          <GlassCard key={stat.label} className="flex items-center gap-4">
            <div className={`p-3 rounded-xl bg-secondary ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="font-display text-2xl font-bold">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Predictions */}
        <div className="lg:col-span-2">
          <h2 className="font-display text-xl font-semibold mb-4">Recent Predictions</h2>
          <div className="space-y-3">
            {recentPredictions.map((item) => (
              <GlassCard key={item.title} className="flex items-center justify-between py-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${item.status === "up" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"}`}>
                    {item.status === "up" ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="font-medium text-sm">{item.title}</div>
                    <div className="text-xs text-muted-foreground">{item.time}</div>
                  </div>
                </div>
                <span className={`font-display font-semibold text-sm ${item.status === "up" ? "text-green-400" : "text-red-400"}`}>
                  {item.change}
                </span>
              </GlassCard>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="font-display text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="space-y-3">
            {[
              { icon: Zap, label: "New Prediction", desc: "Predict a topic" },
              { icon: BarChart3, label: "View Analytics", desc: "Track accuracy" },
              { icon: Users, label: "Find Experts", desc: "Browse professionals" },
            ].map((action) => (
              <GlassCard key={action.label} className="flex items-center gap-3 cursor-pointer py-4">
                <div className="p-2 rounded-lg bg-primary/10">
                  <action.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="font-medium text-sm">{action.label}</div>
                  <div className="text-xs text-muted-foreground">{action.desc}</div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </div>
    </PageWrapper>
  );
}
