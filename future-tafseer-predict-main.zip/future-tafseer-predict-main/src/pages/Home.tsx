import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { Brain, TrendingUp, Compass, MessageSquare, Zap, ArrowRight, Globe, Sparkles, BarChart3, Users } from "lucide-react";
import PageWrapper from "@/components/PageWrapper";
import GlassCard from "@/components/GlassCard";

const heroMessages = [
  "The future belongs to those who predict it.",
  "AI-powered insights for smarter decisions.",
  "Transform uncertainty into opportunity.",
  "See tomorrow's trends, today.",
  "Innovation starts with foresight.",
];

const quickActions = [
  { icon: Brain, label: "Predict", desc: "AI predictions", to: "/predict", color: "text-primary" },
  { icon: TrendingUp, label: "Invest", desc: "Smart ideas", to: "/investments", color: "text-green-400" },
  { icon: Compass, label: "Explore", desc: "Discover trends", to: "/professionals", color: "text-accent" },
  { icon: MessageSquare, label: "Talk to AI", desc: "AI assistant", to: "/ai-assistant", color: "text-yellow-400" },
];

const trendingItems = [
  { title: "AI in Healthcare 2026", category: "Technology", confidence: 92 },
  { title: "Green Energy Investments", category: "Investment", confidence: 87 },
  { title: "Remote Work Evolution", category: "Career", confidence: 85 },
  { title: "Crypto Market Outlook", category: "Finance", confidence: 78 },
  { title: "EdTech Revolution", category: "Education", confidence: 90 },
  { title: "Climate Tech Startups", category: "Business", confidence: 83 },
];

export default function Home() {
  const [msgIndex, setMsgIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMsgIndex((i) => (i + 1) % heroMessages.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <PageWrapper>
      {/* Hero */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-accent/5 blur-[120px]" />

        <div className="relative container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-sm text-muted-foreground mb-8">
              <Sparkles className="w-4 h-4 text-primary" />
              Powered by Advanced AI
            </div>

            <h1 className="font-display text-4xl sm:text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Predict the{" "}
              <span className="gradient-text">Future</span>
              <br />
              with AI Intelligence
            </h1>

            <div className="h-10 mb-8">
              <AnimatePresence mode="wait">
                <motion.p
                  key={msgIndex}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.5 }}
                  className="text-lg md:text-xl text-muted-foreground"
                >
                  {heroMessages[msgIndex]}
                </motion.p>
              </AnimatePresence>
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/predict"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-opacity"
              >
                Start Predicting <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/dashboard"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl glass text-foreground font-semibold hover:bg-card/80 transition-colors"
              >
                View Dashboard
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="container mx-auto px-4 -mt-20 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickActions.map((action, i) => (
            <motion.div
              key={action.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
            >
              <Link to={action.to}>
                <GlassCard className="text-center group cursor-pointer">
                  <action.icon className={`w-8 h-8 mx-auto mb-3 ${action.color} group-hover:scale-110 transition-transform`} />
                  <h3 className="font-display font-semibold">{action.label}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{action.desc}</p>
                </GlassCard>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Stats */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: Brain, value: "10K+", label: "Predictions Made" },
            { icon: Users, value: "5K+", label: "Professionals" },
            { icon: Globe, value: "50+", label: "Countries" },
            { icon: BarChart3, value: "89%", label: "Accuracy Rate" },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <stat.icon className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="font-display text-3xl font-bold">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Trending */}
      <section className="container mx-auto px-4 pb-20">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-display text-2xl md:text-3xl font-bold">
              Trending <span className="gradient-text">Futures</span>
            </h2>
            <p className="text-muted-foreground mt-1">Hot predictions & investment ideas</p>
          </div>
          <Link to="/predict" className="text-sm text-primary hover:underline flex items-center gap-1">
            View All <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {trendingItems.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <GlassCard>
                <div className="flex items-start justify-between mb-3">
                  <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary">{item.category}</span>
                  <span className="text-xs text-muted-foreground">{item.confidence}% confidence</span>
                </div>
                <h3 className="font-display font-semibold mb-2">{item.title}</h3>
                <div className="w-full bg-secondary rounded-full h-1.5">
                  <div
                    className="h-1.5 rounded-full bg-gradient-to-r from-primary to-accent"
                    style={{ width: `${item.confidence}%` }}
                  />
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>
    </PageWrapper>
  );
}
