import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import PageWrapper from "@/components/PageWrapper";

const faqs = [
  { q: "What is FutureScope AI?", a: "FutureScope AI is an all-in-one platform for AI-powered predictions, investment ideas, professional insights, and AI assistance. We use advanced machine learning to help you see what's coming next." },
  { q: "Are the predictions accurate?", a: "Our AI provides predictions based on data analysis and trends. While we strive for high accuracy (shown as confidence scores), all predictions are for informational purposes and should not be taken as financial or professional advice." },
  { q: "Is FutureScope AI free to use?", a: "We offer a free tier with basic features. Premium plans unlock advanced predictions, exclusive professional insights, voice/video calls, and more." },
  { q: "What payment methods are supported?", a: "We support JazzCash and EasyPaisa for Pakistan-based users, along with international payment methods." },
  { q: "Can I become a professional on the platform?", a: "Yes! Professionals can create profiles, post insights and predictions, and build a following. Sign up and set up your professional profile to get started." },
  { q: "How does the AI Assistant work?", a: "Our AI Assistant can answer questions about future trends, provide investment advice, career guidance, and more. It supports all languages and can be accessed from anywhere on the platform." },
  { q: "Is my data secure?", a: "Absolutely. We use industry-standard encryption and security practices. Your personal data and predictions are kept private and secure." },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <PageWrapper className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="text-center mb-10">
        <h1 className="font-display text-3xl font-bold mb-2">
          Frequently Asked <span className="gradient-text">Questions</span>
        </h1>
        <p className="text-muted-foreground">Everything you need to know about FutureScope AI</p>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, i) => (
          <div
            key={i}
            className="glass rounded-xl overflow-hidden"
          >
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex items-center justify-between p-4 text-left"
            >
              <span className="font-medium text-sm pr-4">{faq.q}</span>
              <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ${open === i ? "rotate-180" : ""}`} />
            </button>
            <AnimatePresence>
              {open === i && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "auto" }}
                  exit={{ height: 0 }}
                  className="overflow-hidden"
                >
                  <p className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{faq.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
}
